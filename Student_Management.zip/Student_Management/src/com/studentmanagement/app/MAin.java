package com.studentmanagement.app;

import com.studentmanagement.dao.StudentDAO;
import com.studentmanagement.dao.MarksDAO;
import com.studentmanagement.model.Student;
import com.studentmanagement.model.SMarks;

import java.util.Scanner;

public class MAin {
	private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        StudentDAO studentDAO = new StudentDAO();
        MarksDAO marksDAO = new MarksDAO();

        
        while (true) {
            System.out.println("\nStudent Management System");
            System.out.println("\n-----------------------------------------------------");
            System.out.println("1. View All Students");
            System.out.println("2. Add a Student");
            System.out.println("3. Delete Student Details");
            System.out.println("4. Update Student Details");
            System.out.println("5. View All Marks");
            System.out.println("6. Add Marks");
            System.out.println("7. Delete Marks");
            System.out.println("8. Update Marks");
            System.out.println("9. Generate Report of Student Details");
            System.out.println("10. Generate Mark Sheet");
            System.out.println("11. Exit");
            System.out.println("\n-----------------------------------------------------");
            System.out.print("Enter your choice: ");

            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    studentDAO.viewAllStudents();
                    break;
                case 2:
                    addStudent(scanner, studentDAO);
                    break;
                case 3:
                    deleteStudent(scanner, studentDAO);
                    break;
                case 4:
                    updateStudent(scanner, studentDAO);
                    break;
                case 5:
                    viewMarks(scanner, marksDAO);
                    break;
                case 6:
                    addMarks(scanner, marksDAO);
                    break;
                case 7:
                    deleteMarks(scanner, marksDAO);
                    break;
                case 8:
                    updateMarks(scanner, marksDAO);
                    break;
                case 9:
                    generateReport(studentDAO);
                    break;
                case 10:
                    generateMarkSheet(marksDAO);
                    break;
                case 11:
                    System.out.println("Exiting...");
                    System.exit(0);
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void addStudent(Scanner scanner, StudentDAO studentDAO) {
        System.out.println("\nAdding a New Student");

        System.out.print("Enter First Name: ");
        String firstName = scanner.next();

        System.out.print("Enter Last Name: ");
        String lastName = scanner.next();

        System.out.print("Enter Age: ");
        int age = scanner.nextInt();

        Student newStudent = new Student();
        newStudent.setFirstName(firstName);
        newStudent.setLastName(lastName);
        newStudent.setAge(age);

        studentDAO.addStudent(newStudent);
        System.out.println("Student added successfully.");
    }

    private static void deleteStudent(Scanner scanner, StudentDAO studentDAO) {
        System.out.println("\nDeleting a Student");

        System.out.print("Enter Student ID to delete: ");
        int studentId = scanner.nextInt();

        studentDAO.deleteStudent(studentId);
        System.out.println("Student deleted successfully.");
    }

    private static void updateStudent(Scanner scanner, StudentDAO studentDAO) {
        System.out.println("\nUpdating Student Details");

        System.out.print("Enter Student ID to update: ");
        int studentId = scanner.nextInt();

        Student existingStudent = studentDAO.getStudentById(studentId);

        if (existingStudent == null) {
            System.out.println("Student not found with ID: " + studentId);
            return;
        }

        System.out.print("Enter new First Name: ");
        String newFirstName = scanner.next();

        System.out.print("Enter new Last Name: ");
        String newLastName = scanner.next();

        System.out.print("Enter new Age: ");
        int newAge = scanner.nextInt();

        existingStudent.setFirstName(newFirstName);
        existingStudent.setLastName(newLastName);
        existingStudent.setAge(newAge);

        studentDAO.updateStudent(existingStudent);
        System.out.println("Student details updated successfully.");
    }

    private static void generateReport(StudentDAO studentDAO) {
        studentDAO.generateReport();
    }

    private static void addMarks(Scanner scanner, MarksDAO marksDAO) {
        System.out.println("\nAdding Marks");

        System.out.print("Enter Student ID: ");
        int studentId = scanner.nextInt();

        System.out.print("Enter Marks (Math): ");
        int marksMath = scanner.nextInt();

        System.out.print("Enter Marks (Science): ");
        int marksScience = scanner.nextInt();

        System.out.print("Enter Marks (English): ");
        int marksEnglish = scanner.nextInt();

        marksDAO.addMarks(studentId, marksMath, marksScience, marksEnglish);
        System.out.println("Marks added successfully.");
    }

    private static void viewMarks(Scanner scanner, MarksDAO marksDAO) {
        System.out.println("\nViewing Marks");

        System.out.print("Enter Student ID: ");
        int studentId = scanner.nextInt();

        marksDAO.viewMarks(studentId);
    }

    private static void deleteMarks(Scanner scanner, MarksDAO marksDAO) {
        System.out.println("\nDeleting Marks");

        System.out.print("Enter Student ID: ");
        int studentId = scanner.nextInt();

        marksDAO.deleteMarks(studentId);
        System.out.println("Marks deleted successfully.");
    }

    private static void updateMarks(Scanner scanner, MarksDAO marksDAO) {
        System.out.println("\nUpdating Marks");

        System.out.print("Enter Student ID: ");
        int studentId = scanner.nextInt();

        System.out.print("Enter new Marks (Math): ");
        int marksMath = scanner.nextInt();

        System.out.print("Enter new Marks (Science): ");
        int marksScience = scanner.nextInt();

        System.out.print("Enter new Marks (English): ");
        int marksEnglish = scanner.nextInt();

        marksDAO.updateMarks(studentId, marksMath, marksScience, marksEnglish);
        System.out.println("Marks updated successfully.");
    
    SMarks studentMarks = new SMarks();
    studentMarks.setMarksMath(marksEnglish);
    studentMarks.setMarksScience(marksEnglish);
    studentMarks.setMarksEnglish(marksEnglish);
    }
    // Generate and display the mark sheet
    private static void generateMarkSheet(MarksDAO marksDAO) {
        System.out.println("\nGenerating Mark Sheet");

        System.out.print("Enter Student ID: ");
        int studentId = scanner.nextInt();

        SMarks studentMarks = marksDAO.getStudentMarks(studentId);

        if (studentMarks != null) {
            studentMarks.generateMarkSheet();
        } else {
            System.out.println("Marks not found for Student ID: " + studentId);
        }
    }


}
