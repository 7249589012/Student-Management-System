package com.studentmanagement.model;

public class SMarks {
    private int studentId;
    private int marksMath;
    private int marksScience;
    private int marksEnglish;

    // Constructors, getters, and setters

    public int getStudentId() {
        return studentId;
    }

    public void setStudentId(int studentId) {
        this.studentId = studentId;
    }

    public int getMarksMath() {
        return marksMath;
    }

    public void setMarksMath(int marksMath) {
        this.marksMath = marksMath;
    }

    public int getMarksScience() {
        return marksScience;
    }

    public void setMarksScience(int marksScience) {
        this.marksScience = marksScience;
    }

    public int getMarksEnglish() {
        return marksEnglish;
    }

    public void setMarksEnglish(int marksEnglish) {
        this.marksEnglish = marksEnglish;
    }

    public void generateMarkSheet() {
        int totalMarks = marksMath + marksScience + marksEnglish;
        double averageMarks = totalMarks / 3.0;

        System.out.println("--------- Mark Sheet ---------");
        System.out.println("Marks (Math): " + marksMath);
        System.out.println("Marks (Science): " + marksScience);
        System.out.println("Marks (English): " + marksEnglish);
        System.out.println("Total Marks: " + totalMarks);
        System.out.println("Average Marks: " + averageMarks);
        System.out.println("Grade: " + calculateGrade(averageMarks));
        System.out.println("-------------------------------");
    }

    private String calculateGrade(double averageMarks) {
        if (averageMarks >= 90) {
            return "A";
        } else if (averageMarks >= 80) {
            return "B";
        } else if (averageMarks >= 70) {
            return "C";
        } else if (averageMarks >= 60) {
            return "D";
        } else {
            return "F";
        }
		
	}
    
    @Override
    public String toString() {
        return "Marks{" +
                "studentId=" + studentId +
                ", marksMath=" + marksMath +
                ", marksScience=" + marksScience +
                ", marksEnglish=" + marksEnglish +
                '}';
    }
}
