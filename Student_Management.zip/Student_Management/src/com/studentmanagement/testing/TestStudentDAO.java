package com.studentmanagement.testing;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import com.studentmanagement.dao.StudentDAO;
import com.studentmanagement.model.Student;


import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
//import static org.junit.jupiter.api.Assertions.assertNotNull;

public class TestStudentDAO {

    private StudentDAO studentDAO;

    @BeforeEach
    public void setup() {
        studentDAO = new StudentDAO();
    }

    @Test
    public void testDeleteStudent() {
        Student student = new Student();
        student.setFirstName("John");
        student.setLastName("Doe");
        student.setAge(25);
        studentDAO.addStudent(student);

        assertDoesNotThrow(() -> studentDAO.deleteStudent(student.getStudentId()));
    }

//    @Test
//    public void testUpdateStudent() {
//        Student student = new Student();
//        student.setFirstName("John");
//        student.setLastName("Doe");
//        student.setAge(25);
//        studentDAO.addStudent(student);
//
//        student.setFirstName("UpdatedName");
//        student.setLastName("UpdatedLastName");
//        student.setAge(30);
//
//        assertDoesNotThrow(() -> studentDAO.updateStudent(student));
//
//        // Assuming getStudentId() returns null if the student is not found
//        Student retrievedStudent = studentDAO.getStudentId(student.getStudentId());
//        assertNotNull(retrievedStudent);
//    }
}
