package com.studentmanagement.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.studentmanagement.model.SMarks;

public class MarksDAO {
    private static final String URL = "jdbc:mysql://localhost:3306/studentdb";
    private static final String USER = "root";
    private static final String PASSWORD = "welcome12#";

    public void viewMarks(int studentId) {
        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD)) {
            String query = "SELECT * FROM marks WHERE student_id = ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setInt(1, studentId);
                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    if (resultSet.next()) {
                        System.out.println("\nMarks Details for Student ID: " + studentId);
                        System.out.println("Marks (Math): " + resultSet.getInt("marks_math"));
                        System.out.println("Marks (Science): " + resultSet.getInt("marks_science"));
                        System.out.println("Marks (English): " + resultSet.getInt("marks_english"));
                    } else {
                        System.out.println("Marks not found for Student ID: " + studentId);
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void addMarks(int studentId, int marksMath, int marksScience, int marksEnglish) {
        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD)) {
            String query = "INSERT INTO marks (student_id, marks_math, marks_science, marks_english) VALUES (?, ?, ?, ?)";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setInt(1, studentId);
                preparedStatement.setInt(2, marksMath);
                preparedStatement.setInt(3, marksScience);
                preparedStatement.setInt(4, marksEnglish);
                preparedStatement.executeUpdate();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deleteMarks(int studentId) {
        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD)) {
            String query = "DELETE FROM marks WHERE student_id = ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setInt(1, studentId);
                preparedStatement.executeUpdate();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void updateMarks(int studentId, int marksMath, int marksScience, int marksEnglish) {
        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD)) {
            String query = "UPDATE marks SET marks_math = ?, marks_science = ?, marks_english = ? WHERE student_id = ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setInt(1, marksMath);
                preparedStatement.setInt(2, marksScience);
                preparedStatement.setInt(3, marksEnglish);
                preparedStatement.setInt(4, studentId);
                preparedStatement.executeUpdate();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public SMarks getStudentMarks(int studentId) {
        SMarks studentMarks = null;

        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD)) {
            String query = "SELECT * FROM marks WHERE student_id = ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setInt(1, studentId);
                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    if (resultSet.next()) {
                        studentMarks = new SMarks();
                        studentMarks.setStudentId(resultSet.getInt("student_id"));
                        studentMarks.setMarksMath(resultSet.getInt("marks_math"));
                        studentMarks.setMarksScience(resultSet.getInt("marks_science"));
                        studentMarks.setMarksEnglish(resultSet.getInt("marks_english"));
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return studentMarks;
    }

}
