package com.studentmanagement.dao;

import com.studentmanagement.model.Student;
import java.sql.*;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class StudentDAO {
	
    public List<Student> getAllStudents() {
        List<Student> students = new ArrayList<>();

        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/studentdb", "root", "welcome12#")) {
            String query = "SELECT * FROM students";
            try (Statement statement = connection.createStatement();
                 ResultSet resultSet = statement.executeQuery(query)) {
                while (resultSet.next()) {
                    Student student = new Student();
                    student.setStudentId(resultSet.getInt("student_id"));
                    student.setFirstName(resultSet.getString("first_name"));
                    student.setLastName(resultSet.getString("last_name"));
                    student.setAge(resultSet.getInt("age"));
                    students.add(student);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return students;
    }

    public void addStudent(Student student) {
        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/studentdb", "root", "welcome12#")) {
            String query = "INSERT INTO students (first_name, last_name, age) VALUES (?, ?, ?)";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setString(1, student.getFirstName());
                preparedStatement.setString(2, student.getLastName());
                preparedStatement.setInt(3, student.getAge());
                preparedStatement.executeUpdate();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    public void viewAllStudents() {
        List<Student> students = getAllStudents();

        if (students.isEmpty()) {
            System.out.println("No students found.");
        } else {
            System.out.println("\nList of Students:");
            for (Student student : students) {
                System.out.println(
                        student.getStudentId() + ". " + student.getFirstName() + " " + student.getLastName() +
                                " (Age: " + student.getAge() + ")");
            }
        }
    }
    public void deleteStudent(int studentId) {
        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/studentdb", "root", "welcome12#")) {
            String query = "DELETE FROM students WHERE student_id = ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setInt(1, studentId);
                preparedStatement.executeUpdate();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void updateStudent(Student student) {
        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/studentdb", "root", "welcome12#")) {
            String query = "UPDATE students SET first_name = ?, last_name = ?, age = ? WHERE student_id = ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setString(1, student.getFirstName());
                preparedStatement.setString(2, student.getLastName());
                preparedStatement.setInt(3, student.getAge());
                preparedStatement.setInt(4, student.getStudentId());
                preparedStatement.executeUpdate();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

	public Student getStudentId(int studentId) {
		// TODO Auto-generated method stub
		        return null;
	}
	
	public void generateReport() {
        List<Student> students = getAllStudents();

        if (students.isEmpty()) {
            System.out.println("No students found for generating a report.");
            return;
        }

        System.out.println("----- Student Management Report -----");
        System.out.println("Total Students: " + students.size());
        System.out.println("\n-----------------------------------------------------");

        Student minAgeStudent = findMinAgeStudent(students);
        if (minAgeStudent != null) {
            System.out.println("Minimum Age Student: " + minAgeStudent);
        }

        Student maxAgeStudent = findMaxAgeStudent(students);
        if (maxAgeStudent != null) {
            System.out.println("Maximum Age Student: " + maxAgeStudent);
        }

        System.out.println("-------------------------------------");
    }

    private Student findMinAgeStudent(List<Student> students) {
        if (students.isEmpty()) {
            return null;
        }

        Student minAgeStudent = students.get(0);

        for (Student student : students) {
            if (student.getAge() < minAgeStudent.getAge()) {
                minAgeStudent = student;
            }
        }

        return minAgeStudent;
    }

    private Student findMaxAgeStudent(List<Student> students) {
        if (students.isEmpty()) {
            return null;
        }

        Student maxAgeStudent = students.get(0);

        for (Student student : students) {
            if (student.getAge() > maxAgeStudent.getAge()) {
                maxAgeStudent = student;
            }
        }

        return maxAgeStudent;
    }
    
    public Student getStudentById(int studentId) {
        // Implement logic to retrieve a student by ID
        // You can use a SELECT query similar to getAllStudents()
        // Return the Student object or null if not found
        return null;
    }

	public void generateMarkSheet() {
		// TODO Auto-generated method stub
		
	}

}
	