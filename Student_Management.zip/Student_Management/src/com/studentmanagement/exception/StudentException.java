// UpdateStudentException.java
package com.studentmanagement.exception;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import com.studentmanagement.model.Student;

public class StudentException extends Exception {

	public StudentException(String message) {
        super(message);
    }
    
    public void updateStudent(Student student) throws StudentException {
        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/studentdb", "root", "welcome12#")) {
            String query = "UPDATE students SET first_name = ?, last_name = ?, age = ? WHERE student_id = ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setString(1, student.getFirstName());
                preparedStatement.setString(2, student.getLastName());
                preparedStatement.setInt(3, student.getAge());
                preparedStatement.setInt(4, student.getStudentId());
                int affectedRows = preparedStatement.executeUpdate();

                if (affectedRows == 0) {
                    throw new StudentException("Student not found with ID: " + student.getStudentId());
                }
            }
        } catch (SQLException e) {
            throw new StudentException("Error updating student: " + e.getMessage());
        }
    }
    
}
